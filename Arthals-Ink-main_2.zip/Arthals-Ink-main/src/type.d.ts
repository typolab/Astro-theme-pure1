declare module 'virtual:config' {
  const Config: import('astro-pure/types').ConfigOutput
  export default Config
}
