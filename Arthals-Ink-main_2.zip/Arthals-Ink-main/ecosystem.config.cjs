module.exports = {
  apps: [
    {
      name: 'Ink',
      script: 'bun run preview',
      log_date_format: 'YYYY-MM-DD HH:mm:ss'
    }
  ]
}
